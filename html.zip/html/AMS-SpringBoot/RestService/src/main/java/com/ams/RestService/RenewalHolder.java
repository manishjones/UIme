package com.ams.RestService;

import java.util.Date;

public class RenewalHolder {

	private String id;
	private Date doe;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getDoe() {
		return doe;
	}
	public void setDoe(Date doe) {
		this.doe = doe;
	}
	
}
