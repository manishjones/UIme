package com.ams.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ams.model.Agent;

public interface AgentRepository extends JpaRepository<Agent, String> {

}
