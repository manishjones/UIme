package com.ams.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ams.model.AdminPassword;
import com.ams.model.RegisteredPolicy;

public interface RegisteredPolicyRepository extends JpaRepository<RegisteredPolicy, Long> {
}
