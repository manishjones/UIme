package com.ams.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ams.RestService.AgentHolder;
import com.ams.RestService.AppointmentHolder;
import com.ams.RestService.CustomerHolder;
import com.ams.RestService.PolicyHolder;
import com.ams.RestService.RegisteredPolicyHolder;
import com.ams.RestService.RenewalHolder;
import com.ams.model.AdminPassword;
import com.ams.model.Agent;
import com.ams.model.Appointment;
import com.ams.model.Customer;
import com.ams.model.CustomerPassword;
import com.ams.model.Policy;
import com.ams.model.RegisteredPolicy;
import com.ams.repo.AdminPasswordRepository;
import com.ams.repo.AdminRepository;
import com.ams.repo.AgentRepository;
import com.ams.repo.AppointmentRepository;
import com.ams.repo.CustomerPasswordRepository;
import com.ams.repo.CustomerRepository;
import com.ams.repo.PolicyRepository;
import com.ams.repo.RegisteredPolicyRepository;

@RestController
@CrossOrigin
public class RestResourse {

	@Autowired
	private AdminPasswordRepository apr;
	@Autowired
	private AdminRepository ar;
	@Autowired
	private AppointmentRepository aptr;
	@Autowired
	private CustomerPasswordRepository cpr;
	@Autowired
	private CustomerRepository cr;
	@Autowired
	private PolicyRepository pr;
	@Autowired
	private RegisteredPolicyRepository rpr;
	@Autowired
	private AgentRepository agr;

	@GetMapping("/admin/password/{id}")
	public @ResponseBody ResponseEntity<String> getAdminPassword(@PathVariable String id) {
		List<AdminPassword> list = apr.getAdminPassword(id);
		if (!list.isEmpty()) {
			return new ResponseEntity<String>(list.get(0).getPassword(), HttpStatus.FOUND);
		}
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/customer/password/{id}")
	public @ResponseBody ResponseEntity<String> getCustomerPassword(@PathVariable String id) {
		List<CustomerPassword> list = cpr.getCustomerPassword(id);
		if (!list.isEmpty()) {
			return new ResponseEntity<String>(list.get(0).getPassword(), HttpStatus.FOUND);
		}
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/customer/appointment/{id}")
	public @ResponseBody ResponseEntity<List<Appointment>> getCustomerAppointments(@PathVariable String id) {
		List<Appointment> list = aptr.getCustomerAppointments(id);
		if (!list.isEmpty()) {
			return new ResponseEntity<List<Appointment>>(list, HttpStatus.FOUND);
		}
		return new ResponseEntity<List<Appointment>>(HttpStatus.NOT_FOUND);
	}

	@PostMapping("/customer/register")
	public ResponseEntity<String> registerCustomer(@RequestBody CustomerHolder ch) {

		Customer customer = new Customer();
		CustomerPassword cp = new CustomerPassword();

		customer.setAnnualIncome(ch.getIncome());
		customer.setAnnualPremiums(ch.getPremiums());
		customer.setCity(ch.getCity());
		customer.setContactNumber(ch.getContactno());
		customer.setDateOfBirth(ch.getDob());
		customer.setEmailAddress(ch.getEmail());
		customer.setHeight(ch.getHeight());
		customer.setId(ch.getCid());
		customer.setIdentificationMark(ch.getMark());
		customer.setName(ch.getName());
		customer.setState(ch.getState());
		customer.setWeight(ch.getWeight());
		customer.setZipCode(ch.getZipcode());

		cp.setCustomer(customer);
		cp.setPassword(ch.getPassword());

		if (!cr.existsById(customer.getId())) {
			cr.save(customer);
			cpr.save(cp);
			return new ResponseEntity<String>("Saved", HttpStatus.OK);
		}

		return new ResponseEntity<String>("Not Saved", HttpStatus.EXPECTATION_FAILED);
	}

	@PostMapping("/admin/agent/register")
	public ResponseEntity<String> registerAgent(@RequestBody AgentHolder ah) {

		Agent agent = new Agent();

		agent.setId(ah.getId());
		agent.setName(ah.getName());
		agent.setDateOfBirth(ah.getDob());
		agent.setEmailAddress(ah.getEmail());
		agent.setContactNumber(ah.getContact());
		agent.setAddress(ah.getAddress());
		agent.setCity(ah.getCity());
		agent.setState(ah.getState());
		agent.setZipCode(ah.getZipcode());
		agent.setDateOfBirth(ah.getDob());
		agent.setDateOfJoining(ah.getDoj());
		agent.setEmploymentType(ah.getType());

		if (!agr.existsById(agent.getId())) {
			Agent saved = agr.save(agent);
			if (saved != null)
				return new ResponseEntity<String>("Saved", HttpStatus.OK);
		}

		return new ResponseEntity<String>("Not Saved", HttpStatus.EXPECTATION_FAILED);
	}

	@PostMapping("/customer/appointment/schedule")
	public ResponseEntity<String> scheduleAppointment(@RequestBody AppointmentHolder ah) {

		Appointment appointment = new Appointment();

		Customer customer = cr.findById(ah.getCid()).get();
		Agent agent = agr.findById(ah.getAid()).get();

		appointment.setAgent(agent);
		appointment.setCustomer(customer);
		appointment.setDate(ah.getDoa());
		appointment.setTimeSlot(ah.getSlot());

		Appointment saved = aptr.save(appointment);

		if (saved != null) {
			return new ResponseEntity<String>("Saved", HttpStatus.OK);

		}
		return new ResponseEntity<String>("Not Saved", HttpStatus.EXPECTATION_FAILED);
	}

	@PostMapping("/admin/licence/add")
	public ResponseEntity<String> addLicence(@RequestBody PolicyHolder ph) {

		Policy policy = new Policy();

		policy.setCompanyAddress(ph.getAddress());
		policy.setCompanyEMail(ph.getEmail());
		policy.setCompanyId(ph.getCid());
		policy.setCompanyName(ph.getComname());
		policy.setId(ph.getId());
		policy.setKeyContactName(ph.getConname());
		policy.setKeyContactNumber(ph.getContact());
		policy.setLicenceExpiryDate(ph.getDoe());
		policy.setLicenceRegistryDate(ph.getDor());
		policy.setName(ph.getName());

		if (!pr.existsById(policy.getId())) {
			Policy saved = pr.save(policy);
			if (saved != null) {
				return new ResponseEntity<String>("Saved", HttpStatus.OK);
			}
		}
		return new ResponseEntity<String>("Not Saved", HttpStatus.EXPECTATION_FAILED);
	}

	@PostMapping("/admin/customer/policy/register")
	public ResponseEntity<String> registerPolicy(@RequestBody RegisteredPolicyHolder rph) {

		RegisteredPolicy rPolicy = new RegisteredPolicy();

		Customer customer = cr.findById(rph.getCustid()).get();
		Agent agent = agr.findById(rph.getAgentid()).get();
		Policy policy = pr.findById(rph.getPolid()).get();

		rPolicy.setAgent(agent);
		rPolicy.setBookingDate(rph.getDate());
		rPolicy.setCommissionType(rph.getComtype());
		rPolicy.setCustomer(customer);
		rPolicy.setNomineeDOB(rph.getDob());
		rPolicy.setNomineeName(rph.getName());
		rPolicy.setNomineeRelationship(rph.getRelation());
		rPolicy.setPaymentMode(rph.getMode());
		rPolicy.setPolicy(policy);
		rPolicy.setTotalSumAssured(rph.getSum());

		RegisteredPolicy saved = rpr.save(rPolicy);
		if (saved != null)
			return new ResponseEntity<String>("Saved", HttpStatus.OK);
		return new ResponseEntity<String>("Not Saved", HttpStatus.EXPECTATION_FAILED);
	}
	
	@PutMapping("admin/licence/renew")
	public ResponseEntity<String> renewLicence(@RequestBody RenewalHolder rh) {
		if(pr.existsById(rh.getId())){
			Policy policy=pr.findById(rh.getId()).get();
			policy.setLicenceExpiryDate(rh.getDoe());
			Policy saved=pr.save(policy);
			if(saved!=null) return new ResponseEntity<String>("Success",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Unsuccessful",HttpStatus.EXPECTATION_FAILED);
	}
}